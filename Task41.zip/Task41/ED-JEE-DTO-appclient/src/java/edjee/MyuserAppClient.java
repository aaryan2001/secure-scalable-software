/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edjee;

import entity.MyuserDTO;
import java.util.Scanner;
import java.util.List;
import javax.ejb.EJB;
import session.MyuserFacadeRemote;

/**
 *
 * @author aarya
 */

public class MyuserAppClient {

    @EJB
    private static MyuserFacadeRemote myuserFacade;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String userid;
        String name;
        String password;
        String email;
        String phone;
        String address;
        String secQn;
        String secAns;
        boolean result;
        
        MyuserAppClient client = new MyuserAppClient();
        
        // Simple menu
        Scanner in = new Scanner(System.in);
        boolean stayInMenu = true;
        while (stayInMenu) {
            System.out.println("\n\nSELECT AN OPTION FROM THE MENU \n"
                    + "1: FIND RECORD \n"
                    + "2: CREATE RECORD \n"
                    + "3: UPDATE RECORD \n"
                    + "4: REMOVE RECORD \n"
                    + "5: FIND RECORD BY ADDRESS \n"
                    + "6: EXIT \n");
            int choice = Integer.parseInt(in.nextLine());
            switch (choice) {
                case 1:
                    System.out.println("\n PLEASE ENTER THE USERID TO FIND ");
                    userid = in.nextLine();
                    MyuserDTO myuser = client.getRecord(userid);
                    if (myuser != null) {
                        System.out.println("Name: " + myuser.getName() + "\n"
                        + "Password: " + myuser.getPassword() + "\n"
                        + "Email: " + myuser.getEmail() + "\n"
                        + "Phone: " + myuser.getPhone() + "\n"
                        + "Address: " + myuser.getAddress() + "\n"
                        + "SecQn: " + myuser.getSecQn() + "\n"
                        + "SecAns: " + myuser.getSecAns() + "\n"
                        );
                    } else {
                        System.out.println("\n NO RECORDS FOUND. ");
                    }
                    break;
                case 2:
                    System.out.println("\n USERID: ");
                    userid = in.nextLine();
                    System.out.println("\n NAME: ");
                    name = in.nextLine();
                    System.out.println("\n PASSWORD: ");
                    password = in.nextLine();
                    System.out.println("\n EMAIL: ");
                    email = in.nextLine();
                    System.out.println("\n PHONE: ");
                    phone = in.nextLine();
                    System.out.println("\n ADDRESS: ");
                    address = in.nextLine();
                    System.out.println("\n SECRET QUES: ");
                    secQn = in.nextLine();
                    System.out.println("\n SECRET ANS: ");
                    secAns = in.nextLine();
                    MyuserDTO adduser = new MyuserDTO(userid, name, password, email,
                            phone, address, secQn, secAns);
                    result = client.createRecord(adduser);
                    if (result) {
                        System.out.println("CREATED \n");
                    } else {
                        System.out.println("NOT FOUND \n");
                    }
                    break;
                case 3:
                    System.out.println("\n USERID: ");
                    userid = in.nextLine();
                    System.out.println("\n NAME: ");
                    name = in.nextLine();
                    System.out.println("\n PASSWORD: ");
                    password = in.nextLine();
                    System.out.println("\n EMAIL: ");
                    email = in.nextLine();
                    System.out.println("\n PHONE: ");
                    phone = in.nextLine();
                    System.out.println("\n ADDRESS: ");
                    address = in.nextLine();
                    System.out.println("\n SECRET QUES: ");
                    secQn = in.nextLine();
                    System.out.println("\n SECRET ANS: ");
                    secAns = in.nextLine();
                    MyuserDTO updateuser = new MyuserDTO(userid, name, password, email,
                            phone, address, secQn, secAns);
                    result = client.updateRecord(updateuser);
                    if (result) {
                        System.out.println("\n UPDATED ");
                    } else {
                        System.out.println("\n COUDN'T PERFORM THE ACTION ");
                    }
                    break;
                case 4:
                    System.out.println("\n USERID OF THE USER TO REMOVE: ");
                    userid = in.nextLine();
                    MyuserDTO deleteuser = client.getRecord(userid);
                    if (deleteuser == null) {
                        System.out.println("\n NO DATA FOUND ");
                        break;
                    }
                    result = client.deleteRecord(deleteuser.getUserid());
                    if (result) {
                        System.out.println("\n DELETED ");
                    } else {
                        System.out.println("\n COUDN'T PERFORM THE ACTION ");
                    }
                    break;
                case 5:
                    System.out.println("\n ADDRESS:");
                    address = in.nextLine();
                    List<MyuserDTO> myusers = client.getRecordsByAddress(address);
                    if (myusers == null) {
                        System.out.println("\n NO DATA FOUND");
                        break;
                    } else {
                        for (MyuserDTO myuserDTO : myusers) {
                            System.out.println("\n");
                            System.out.println("Name: " + myuserDTO.getName() + "\n"
                        + "Password: " + myuserDTO.getPassword() + "\n"
                        + "Email: " + myuserDTO.getEmail() + "\n"
                        + "Phone: " + myuserDTO.getPhone() + "\n"
                        + "Address: " + myuserDTO.getAddress() + "\n"
                        + "SecQn: " + myuserDTO.getSecQn() + "\n"
                        + "SecAns: " + myuserDTO.getSecAns() + "\n"
                        );
                        }
                    }
                    break;
                case 6:
                    stayInMenu = false;
                    break;
                default:
                    break;
            }
        }
    }

    public void showCreateResult(boolean result, MyuserDTO myuserDTO) {
        if (result) {
            System.out.println("Record with primary key " + myuserDTO.getUserid()
                    + " has been created in the database table.");
        } else {
            System.out.println("Record with primary key " + myuserDTO.getUserid()
                    + " could not be created in the database table!");
        }
    }

    public Boolean createRecord(MyuserDTO myuserDTO) {
        return myuserFacade.createRecord(myuserDTO);
    }
    
    public MyuserDTO getRecord(String userId) {
        return myuserFacade.getRecord(userId);
    }

    public boolean updateRecord(MyuserDTO myuserDTO) {
        return myuserFacade.updateRecord(myuserDTO);
    }
    
    public boolean deleteRecord(String userId) {
        return myuserFacade.deleteRecord(userId);
    }
    
    public List<MyuserDTO> getRecordsByAddress(String address) {
        return myuserFacade.getRecordsByAddress(address);
    }
}